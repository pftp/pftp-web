// Problem 2 (Peekaboo) ------------------------------------------------------
// WRITE CODE HERE

// Problem 3 (Swap Em) -----------------------------------------------
// WRITE CODE HERE

// Problem 4 (Find the Source) -------------------------------------------------
$('.clickable').click(function() {
  // WRITE CODE HERE
});

// Problem 5 (Imgrr) -------------------------------------------------
// WRITE CODE HERE
