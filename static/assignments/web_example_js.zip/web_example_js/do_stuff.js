$(function() {

  var colors = ['red', 'blue', 'green', 'white', 'black', 'yellow', 'orange', 'cyan'];
  var angle = 0;

  $('#change_color').click(function() {
    var rand_index = Math.floor(Math.random() * colors.length);
    document.body.style.background = colors[rand_index];
  });

  $('#toggle_pic').click(function() {
    if ($('#toggle_pic').text() === 'Hide the Photo') {
      $('#corgi').hide();
      $('#toggle_pic').text('Show the Photo');
    } else {
      $('#corgi').show();
      $('#toggle_pic').text('Hide the Photo');
    }
  });

  $('#rotate_pic').click(function() {
    angle += parseInt($('#rotate_amount').val());
    $('#corgi').rotate(angle);
  });
});
