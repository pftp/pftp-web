alert('Welcome to my stuff page!'); // edit me!

// Problem 1 (Say Hello!) ---------------------------------------------------
$('#say_hello').click(function() {
  // WRITE CODE HERE
});


// Problem 2 (Houdini) ------------------------------------------------------
$('#disappear').click(function() {
  //WRITE CODE HERE
});

$('#reappear').click(function() {
  //WRITE CODE HERE
});


// Problem 3 (Tickle Me Pink) -----------------------------------------------
// WRITE CODE HERE


// Problem 4 (Greet Me) -----------------------------------------------------
// WRITE CODE HERE
