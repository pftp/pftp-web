$(function() {
  var getChatbotResponse = function(h) {
    if (h === "hello") {
      return "hello there!";
    }
    return "I don't understand that input";
  };

  var sendInput = function() {
    var humanInput = $('#human_input').val();
    var prevOutput = $('#output_area').val();
    $('#output_area').val('You: ' + humanInput + '\n' + prevOutput);
    $('#human_input').val('');
    setTimeout(function() {
      var prevOutput = $('#output_area').val();
      var chatbotResponse = getChatbotResponse(humanInput);
      $('#output_area').val('Chatbot: ' + chatbotResponse + '\n' + prevOutput);
    }, 500);
  };

  $('#send_input').click(sendInput);
  var keyPress = function(e) {
    if (e.keyCode == 13) {
      sendInput();
    }
  };
  window.addEventListener('keypress', keyPress);
});
