$(document).ready(function() {
  //this is how we acquire control of the canvas
  var canvas = $('#canvas')[0];
  var context = canvas.getContext("2d");

  $('#clear').click(function() {
    context.clearRect(0, 0, canvas.width, canvas.height);
  });

  //---------------------------------------------------------------------------
  //Write your code for p1-p12 here
  //

});
